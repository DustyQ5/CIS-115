/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m5lab2;
import java.util.Scanner; 
/**
 *
 * @author sawyerc6398
 */
public class M5LAB2 {

    public static void main(String[] args) {
   
    System.out.println("This is the M5LABS2 menu");
    System.out.println("1. Be greeted");
    System.out.println("2. Double a number");
    System.out.println("3. Ten percent of a double number");
    System.out.println("4. Calculate gross pay");
    
   
  // menu choice input
  Scanner keyboard = new Scanner(System.in);
  int menu_choice = keyboard.nextInt();



  if(menu_choice == 1){
    greet_user();
  }// If 1 end
  else if(menu_choice == 2){
    double_number();
  }// If 2 end
  else if(menu_choice == 3){
    ten_percent();
  }// If 3 end
  else if(menu_choice == 4){
    gross_pay();
  }// If 4 end
  else if(menu_choice != 1 || menu_choice != 2 || menu_choice != 3 || menu_choice != 4){
      System.out.println("Your previous choice is not supported by this menu module");
      menu_choice_repeat();
  }
    
    /*// Function Testing Ground
    

    */

  }



  // This function greets the user
  public static void greet_user(){
    System.out.println("Hello, User.");
  }// greet user functioin ends


  // This function doubles a number
  public static void double_number(){
    System.out.println("This program will double a number that is equal to double the number you input.");
    Scanner keyboard_double = new Scanner(System.in);
    int number_to_double = keyboard_double.nextInt();
    int doubled_number = number_to_double * 2;
    System.out.println("Your doubled number is: " + doubled_number);
  }// double number function ends


  // This function gives ten percent of a number
  public static void ten_percent(){
    System.out.println("This program will return a value equal to ten percent of the number you input.");
    Scanner keyboard_ten_percent = new Scanner(System.in);
    float keyboard_x = keyboard_ten_percent.nextFloat();
    // divide x by ten multiply by 9 subtract by original x
    float ten_percent_y = (((keyboard_x/10)*9) - keyboard_x);
    //ten percent comes out as negative - subtract a negative by itself twice to get a positive
    float ten_percent_z = ten_percent_y - ten_percent_y - ten_percent_y;
    System.out.println("Ten percent of your number is: " + ten_percent_z);
  }//ten percent function ends

  //gross pay function begins
  public static void gross_pay(){
    System.out.println("This program will calculate your gross pay");
    System.out.println("What is your hourly rate?");
    Scanner keyboard_gross = new Scanner(System.in);
    float hour_rate = keyboard_gross.nextFloat();
    System.out.println("How many hours did you work?");
    float hour_work = keyboard_gross.nextFloat();
    float gross = hour_rate * hour_work;
    System.out.println("Your gross pay is: " + gross);
    /* pay per hour = x
    hours worked = y
     */
  }//gross pay function ends
  
  //menu choice function repeats on false answer
  public static void menu_choice_repeat(){
  Scanner keyboard = new Scanner(System.in);
  int menu_choice = keyboard.nextInt();

   System.out.println("This is the M5LABS2 menu");
   System.out.println("1. Be greeted");
   System.out.println("2. Double a number");
   System.out.println("3. Ten percent of a double number");
   System.out.println("4. Calculate gross pay");
  
  if(menu_choice == 1){
    greet_user();
  }// If 1 end
  else if(menu_choice == 2){
    double_number();
  }// If 2 end
  else if(menu_choice == 3){
    ten_percent();
  }// If 3 end
  else if(menu_choice == 4){
    gross_pay();
  }// If 4 end
  else if(menu_choice != 1 || menu_choice != 2 || menu_choice != 3 || menu_choice != 4){
      System.out.println("Your previous choice is not supported by this menu module");
      menu_choice_repeat();
  }
  
  }//menu repeat choice function ends
  
  
}
    

